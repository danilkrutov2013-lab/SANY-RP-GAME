# SANY RP — сборка APK с телефона

Проект подготовлен для Android Studio / AndroidIDE и для сборки через GitHub Actions без ПК.

## Вариант 1 — AndroidIDE на телефоне

1. Установи AndroidIDE.
2. Распакуй этот ZIP в память телефона.
3. В AndroidIDE выбери **Open existing project** и открой папку `SANY_RP`.
4. Дождись синхронизации Gradle.
5. Запусти `:app:assembleDebug`.
6. APK будет в:
   `app/build/outputs/apk/debug/app-debug.apk`

Для AndroidIDE потребуется установленный Android SDK 35 и JDK 17. Если AndroidIDE предложит установить компоненты SDK — согласись.

## Вариант 2 — GitHub Actions (вообще без локальной сборки)

В проекте уже есть `.github/workflows/build-apk.yml`.

1. Создай новый репозиторий на GitHub с телефона.
2. Загрузи содержимое этой папки в репозиторий.
3. Открой вкладку **Actions**.
4. Запусти workflow **Build APK** через **Run workflow**.
5. После завершения открой запуск workflow → **Artifacts** → `SANY-RP-debug`.
6. Скачай ZIP с APK и распакуй его на телефоне.

Собирается debug APK, который можно установить вручную на Android.

## Конфигурация сервера

Сервер сейчас указан в:
`app/src/main/assets/server.json`

SAN-CITY:
`188.127.241.74:1612`

Примечание: текущая кнопка «ИГРАТЬ» в исходном проекте показывает Toast с адресом сервера; она не запускает сторонний игровой клиент автоматически.
